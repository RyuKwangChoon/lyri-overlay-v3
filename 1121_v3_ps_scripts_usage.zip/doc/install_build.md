🧩 파트너에게 확인 질문

다음 중 어떤 걸 먼저 할까?

1) client용 OverlayView / ControlView 템플릿 생성
2) server용 index.js / api / ws 기본 코드 생성
3) .env + vite.config.ts v3 설정
4) 전체 v3 아키텍처 문서 자동 생성
5) Cursor AI에게 넘길 “개발 초기 명령어 세트”

