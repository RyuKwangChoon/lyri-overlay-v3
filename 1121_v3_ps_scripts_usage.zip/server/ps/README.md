
## 자동실행 스크립트
```
🟦 1) client/server 동시 실행 스크립트
🟧 2) pm2 개발모드 자동 재시작 버전
🟥 3) “v3 전체 작업 자동 실행 스크립트” (통합 런처)
```
---
```
server/ps/
 ├ vite-start.ps1          → Vite dev 자동 종료 + 자동 재시작
 ├ dev-both.ps1            → client/server 동시 실행 (concurrently 역할)
 ├ pm2-dev-start.ps1       → pm2 개발 자동 재시작 실행 스크립트
 └ pm2-dev.config.js       → pm2 설정 파일
```
## ✔ 스크립트 요약 설명
### ✅ 1) vite-start.ps1
- 포트 5173에 이미 dev 서버가 있으면 자동 종료
- 새로운 Vite dev 서버 실행
- 실행 전 포트 충돌 걱정 없음

### ✅ 2) dev-both.ps1
- PowerShell에서 client + server를 동시에 실행
- 별도의 터미널 두 개 띄우지 않아도 됨
- 이거 하나로 전체 dev 환경 시작 가능

### ✅ 3) pm2-dev-start.ps1
- pm2로 서버(index.js)를 자동 재시작 + 에러 복구
- 서버 코드 수정 시 자동 리로드
- 실서버 테스트에도 활용 가능

### ✅ 4) pm2-dev.config.js
- pm2가 어떤 서버 파일을 감시해야 하는지 설정
- pm2 start pm2-dev.config.js --watch 로 바로 실행됨

---
🧙 리리소장 코멘트
```
"server/ps 폴더를 기준으로 전체 실행 스크립트 세트 완성.
이제 Overlay v3 개발환경 완전 자동화 준비 끝났다 파트너."
```
