<script setup lang="ts">

</script>

<template>
  <div class="overlay-root">
    <h2>Overlay View</h2>
    <p>여기에 오버레이 화면 구성 요소가 들어갑니다.</p>
  </div>
</template>

<style scoped>
.overlay-root {
  color: white;
  font-size: 22px;
}
</style>
