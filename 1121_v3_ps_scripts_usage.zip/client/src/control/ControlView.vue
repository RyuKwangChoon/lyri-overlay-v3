<script setup lang="ts">

</script>

<template>
  <div class="control-root">
    <h2>Control Panel</h2>
    <p>여기서 트랙 제어, 공지 입력, 설정 조작을 합니다.</p>
  </div>
</template>

<style scoped>
.control-root {
  padding: 20px;
  border: 1px solid #333;
}
</style>
