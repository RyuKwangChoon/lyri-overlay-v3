<script setup lang="ts">
</script>

<template>
  <main class="app-root">
    <h1>Lyri × Brian Overlay v3</h1>
    <p>기본 템플릿 로드 완료</p>
  </main>
</template>

<style scoped>
.app-root {
  padding: 40px;
  font-size: 20px;
}
</style>
