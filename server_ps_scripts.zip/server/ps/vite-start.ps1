# Vite Dev 서버 자동 종료 + 재시작
Write-Host "🔍 Checking Vite on 5173..."
$proc = netstat -ano | findstr 5173 | Select-String "LISTENING"
if ($proc) {
  $pid = ($proc -split "\s+")[-1]
  Write-Host "Killing PID $pid"
  taskkill /PID $pid /F | Out-Null
}
Write-Host "Starting Vite..."
npm run dev
