# client/server 동시 실행
Start-Process powershell -ArgumentList "cd ../client; npm run dev"
Start-Process powershell -ArgumentList "cd ../server; node index.js"
