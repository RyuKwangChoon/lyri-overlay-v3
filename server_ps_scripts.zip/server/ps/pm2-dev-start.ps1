# pm2 개발모드 자동 재시작
pm2 start pm2-dev.config.js --watch
